var class_s_i2_c_i_o =
[
    [ "SI2CIO", "class_s_i2_c_i_o.html#ae27c1861e885c6ade3f3923658957edf", null ],
    [ "begin", "class_s_i2_c_i_o.html#aef6df8409b67bda118c2e055af3d6f47", null ],
    [ "digitalRead", "class_s_i2_c_i_o.html#a15fe6d174fb001bca7866004e96f0b33", null ],
    [ "digitalWrite", "class_s_i2_c_i_o.html#ae1e3c6fd22872f248de6a90af27d92de", null ],
    [ "pinMode", "class_s_i2_c_i_o.html#a4ef4fb77ddd3d248be5e0898e33430a3", null ],
    [ "portMode", "class_s_i2_c_i_o.html#a8e78ee0ee2d1bb12136b5c5a3487512b", null ],
    [ "read", "class_s_i2_c_i_o.html#a32cb72361397c1051ee650dbb2190060", null ],
    [ "write", "class_s_i2_c_i_o.html#a47c3ac3198cddcf9e6da1ccacd9db5d9", null ]
];