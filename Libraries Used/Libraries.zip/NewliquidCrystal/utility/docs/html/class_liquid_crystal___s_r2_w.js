var class_liquid_crystal___s_r2_w =
[
    [ "LiquidCrystal_SR2W", "class_liquid_crystal___s_r2_w.html#af307fdf5c8feb757e965074dcdeb1dd3", null ],
    [ "send", "class_liquid_crystal___s_r2_w.html#a65dc6f261c319be8e56f3c1f6a5c877d", null ],
    [ "setBacklight", "class_liquid_crystal___s_r2_w.html#a2158db27287c1564a03e7a1472beb3b6", null ]
];