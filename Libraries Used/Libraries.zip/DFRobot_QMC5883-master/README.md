QMC5883L - 3-Axis Digital Compass IC (Compatible with HMC5883L)
---------------------------------------------------------

### initial QMC5883L sensor

scan and initial QMC5883l device 

    bool begin(void);


### read raw data

You can read raw data by this function:

    Vector readRaw(void);


### read Normalize data

You can read raw data by this function:

    Vector readNormalize(void);


### calibrate

In this version optimization, calibration will be removed and calibrated when used.
When the compass program runs, please spin QMC5883 freely to accomplish calibration.


* @n [Get the module here](等上架后添加商品购买链接)
* @n This example Set the volume size and play music snippet.
* @n [Connection and Diagram](等上架后添加wiki链接)
*
* Copyright	[DFRobot](http://www.dfrobot.com), 2016
* Copyright	GNU Lesser General Public License
*
* @author [dexian.huang](952838602@qq.com)
* version  V1.0
* date  2017-7-3

