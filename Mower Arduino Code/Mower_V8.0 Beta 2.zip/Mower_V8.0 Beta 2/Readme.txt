ReP_AL 3D Printed Robot Lawn Mower
----------------------------------

Code V8.0  BETA    04.05.2020
------------------------------

Upload the MEGA code to the Arduino MEGA
Upload the Nano code to the Arduino Nano
Upload the NodeMCU code to the NodeMCU Board   (includes new code)
Upload the TFT Code to the TFT MEGA Shield
Upload the BMP Files to the TFT SD Card


Features of 8.0 BETA
--------------------

- TFT Display is added (TFT_Screen_Menu = 1 in Settings to turn on TFT function
			Ensure LCD_Scree_Keypad_Menu = 0 )
- Bumper Bar is activated in finding wire function
- Angle Stop Capability added
- Tip Over Safety Stop Capability added

Experimental
- Slow at wire function - Slows the mower when it gets to the wire to ensure the wire is detected in time.


Known Issues of 8.0 BETA
------------------------
- With TFT longer reaction time than normal to detect wire (see slow at wire function to help)
- TFT Some menus get stuck when returning to the home screen
- TFT Test scripts dont always start correctly



NodeMCU Board URL:
------------------
Use this URL to add the NodeMCU board 1.0 to the boards menu.

http://arduino.esp8266.com/stable/package_esp8266com_index.json


 
